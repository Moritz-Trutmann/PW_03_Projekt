<!<!doctype html>
<script type="text/javascript">
                    document.getElementById('Jahr').value = "<?php echo $_GET['Jahr']; ?>";
                </script>