# PW2i_08

CO2-Emissionen im Gebäudebereich nach Energieträgern und Gemeinden
