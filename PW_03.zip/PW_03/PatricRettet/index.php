<!DOCTYPE html>
<html>
    <head>
        <?php
        error_reporting(0);
        $dataPoints = array(
            array("label" => "Erdölbrennstoff", "y" => 42.6),
            array("label" => "Erdgas", "y" => 26.6),
            array("label" => "Andere", "y" => 31),
        );
        ?>
        <meta charset="utf-8">

        <script src="js/jquery.min.js"></script>

        <script src="//d3js.org/d3.v3.min.js"></script>
        <script src="//d3js.org/topojson.v1.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script src="js/d3.v3.min.js"></script>
        <script src="js/topojson.v1.min.js"></script>
        <script>function submit() {
                document.getElementById("myform").submit();
            }</script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>

        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

    </head>
    <body>
        <?php
        $id = $_GET['demo'];
        $jahr = $_GET['Jahr'];
        $file = fopen("div-energie-8.csv", "r");
        if (isset($_GET['demo']) && isset($_GET['Jahr'])) {
            while (!feof($file)) {
                $content = fgetcsv($file);
                $count = count($content);
                for ($i = 0; $i < $count; $i++) {
                    $text = explode(";", $content[$i]);
                    if ($text[1] == $id && $text[0] == $jahr) {
                        echo "Gemeindename: " . $text[2] . "<br>";
                        echo "Einwohner: " . $text[3] . "Person<br>";
                        echo "Energiebezugsflaeche: " . $text[4] . "m2<br>";
                        echo 'Erdölbrennstoffe: ' . $text[5] . 'kg<br> Erdgas: ' . $text[6] . 'kg<br> Andere: ' . $text[7] . 'kg<br> Total: ' . $text[8] . 'kg<br>';
                        $einwohner = intval($text[3]);
                        $bezugsfläche = intval($text[4]);
                        $erdöl = intval($text[5]);
                        $erdgas = intval($text[6]);
                        $andere = intval($text[7]);
                        $total = intval($text[8]);
                    }
                }
            }
        }
        ?>
        <script>


            function init() {

                var docu = document.getElementById('graph');

                var width = docu.clientWidth,
                        height = docu.clientHeight,
                        centered,
                        clickBool = false;


                var path = d3.geo.path()
                        .projection(null);

                var svg = d3.select("#graph").append("svg")
                        .attr("width", width)
                        .attr("height", height);

                var graph = d3.select("#graph").append("div")
                        .attr("class", "tooltip")
                        .style("opacity", 0);

                svg.append("rect")
                        .attr("class", "background")
                        .attr("width", width)
                        .attr("height", height)
                        .on("click", clicked);


                var g = svg.append("g")
                        .attr("width", "")
                        .attr("height", "");

                d3.json("json/tg-municipalities-lakes.json", function (error, tg) {
                    switch (btnP) {
                        case "btn1":
                            g.append("g")
                                    .attr("id", "municipalities")
                                    .selectAll("path")
                                    .data(topojson.feature(tg, tg.objects.municipalities).features)
                                    .enter().append("path")
                                    .attr("d", path)
                                    .on("click", clicked)
                                    .on("mouseover", mouseover)
                                    .on("mouseout", mouseout)
                                    .attr("fill", function (d) {
                                        var m = getMPopulation(d);
                                        if (m > 0) {
                                            var a = ((m - (m % Math.round(max / 10))) / Math.round(max / 10));
                                            if (a >= 10) {
                                                a = a - 1;
                                            }
                                            console.log(d.id + ", " + m);
                                            return color[a][1];
                                        }
                                    });

                            console.log("go to Population");
                            break;
                        default:
                            g.append("g")
                                    .attr("id", "municipalities")
                                    .selectAll("path")
                                    .data(topojson.feature(tg, tg.objects.municipalities).features)
                                    .enter().append("path")
                                    .attr("d", path)
                                    .on("click", clicked)
                                    .on("mouseover", mouseover)
                                    .on("mouseout", mouseout);
                            break;

                    }

                    g.append("g")
                            .attr("id", "lakes")
                            .selectAll("path")
                            .data(topojson.feature(tg, tg.objects.lakes).features)
                            .enter().append("path")
                            .attr("d", path);

                    g.append("path")
                            .datum(topojson.mesh(tg, tg.objects.municipalities, function (a, b) {
                                return a !== b;
                            }))
                            .attr("id", "border")
                            .style("stroke-width", "1px")
                            .attr("d", path);
                });

                function clicked(d) {
                    var x, y, k;
                    if (d && centered !== d) {
                        k = 4;
                        centered = d;
                        clickBool = true;
                        document.getElementById("demo").value = d.id;
                        submit();
                    }
                    g.selectAll("path")
                            .classed("active", centered && function (d) {
                                return d === centered;
                            });
                    g.transition()
                            .duration(750)
                            .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")scale(" + k + ")translate(" + -x + "," + -y + ")")
                            .style("stroke-width", 1.5 / k + "px");
                }

                function mouseover(d) {
                    switch (btnP) {
                        default:
                            document.getElementById("demo").value = d.id;
                            graph.style("opacity", .9)
                            
                                    .html(getMName(d) + "<br> Einwohnnerzahl: " + d.id + " " + '<?php echo $einwohner; ?>')
                                    .style("left", (d3.event.pageX) + "px")
                                    .style("top", (d3.event.pageY - 28) + "px");
                            break;
                    }
                }
                function mouseout(d) {
                    graph.style("opacity", 0)
                            .html();
                }

                function getMName(d) {
                    for (i = 0; i < muniArr.length; i++) {
                        if (d.id === muniArr[i][0]) {
                            return muniArr[i][1] || d.id;
                            continue;
                        }
                    }
                }
            }
        </script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {

                var data = google.visualization.arrayToDataTable([
                    ['Task', 'Art'],
                    ['Erdöl', <?php echo $erdöl; ?>],
                    ['Erdgas', <?php echo $erdgas; ?>],
                    ['Andere', <?php echo $andere; ?>],
                ]);

                var options = {
                    title: 'Ausstossmenge kategorisiert'
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                chart.draw(data, options);
            }
        </script>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
<?php
$id = $_GET['demo'];
$jahr = 2015;
$file = fopen("div-energie-8.csv", "r");
if (isset($_GET['demo'])) {
    while (!feof($file)) {
        $content = fgetcsv($file);
        $count = count($content);
        for ($i = 0; $i < $count; $i++) {
            $text = explode(";", $content[$i]);
            if ($text[1] == $id && $text[0] == $jahr) {
                $total1 = intval($text[8]);
            }
        }
    }
}
$jahr = 2016;
$file = fopen("div-energie-8.csv", "r");
if (isset($_GET['demo'])) {
    while (!feof($file)) {
        $content = fgetcsv($file);
        $count = count($content);
        for ($i = 0; $i < $count; $i++) {
            $text = explode(";", $content[$i]);
            if ($text[1] == $id && $text[0] == $jahr) {
                $total2 = intval($text[8]);
            }
        }
    }
}
$jahr = 2017;
$file = fopen("div-energie-8.csv", "r");
if (isset($_GET['demo'])) {
    while (!feof($file)) {
        $content = fgetcsv($file);
        $count = count($content);
        for ($i = 0; $i < $count; $i++) {
            $text = explode(";", $content[$i]);
            if ($text[1] == $id && $text[0] == $jahr) {
                $total3 = intval($text[8]);
            }
        }
    }
}
$jahr = 2018;
$file = fopen("div-energie-8.csv", "r");
if (isset($_GET['demo'])) {
    while (!feof($file)) {
        $content = fgetcsv($file);
        $count = count($content);
        for ($i = 0; $i < $count; $i++) {
            $text = explode(";", $content[$i]);
            if ($text[1] == $id && $text[0] == $jahr) {
                $total4 = intval($text[8]);
            }
        }
    }
}
$jahr = 2019;
$file = fopen("div-energie-8.csv", "r");
if (isset($_GET['demo'])) {
    while (!feof($file)) {
        $content = fgetcsv($file);
        $count = count($content);
        for ($i = 0; $i < $count; $i++) {
            $text = explode(";", $content[$i]);
            if ($text[1] == $id && $text[0] == $jahr) {
                $total5 = intval($text[8]);
            }
        }
    }
}
?>
                var data = google.visualization.arrayToDataTable([
                    ['Year', 'Ausstossmenge'],
                    ['2015', <?php echo $total1; ?>],
                    ['2016', <?php echo $total2; ?>],
                    ['2017', <?php echo $total3; ?>],
                    ['2018', <?php echo $total4; ?>],
                    ['2019', <?php echo $total5; ?>]
                ]);

                var options = {
                    title: 'Ausstossmenge total im Laufe der Jahren',
                    curveType: 'function',
                    legend: {position: 'bottom'}
                };

                var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

                chart.draw(data, options);
            }
        </script>
        <div id="container">
            <form id="myform" name="myform" method="get" action="index.php">
                <h1 id="h1">CO2-Emissione im Kanton <font style="color: green;">Thurgau</font></h1>
                <h3 id="h3">Gemeinde auswählen</h3>
                <div id="graph"></div>
                <h3 id="h3">Jahr auswählen</h3>
                <select name="Jahr" id="Jahr" onchange="submit()">
                    <option value="2015">2015</option>
                    <option value="2016">2016</option>
                    <option value="2017">2017</option>
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                </select>
                <div id="curve_chart" style="width: 1500px; height: 500px"></div>

                <script type="text/javascript">
                    document.getElementById('Jahr').value = "<?php echo $_GET['Jahr']; ?>";
                </script>
                <input id="demo" name="demo" style="display: none" value="<?php echo $_GET['demo']; ?>">
            </form>
            <div id="piechart" style="width: 950px; height: 550px; float: right"></div>
        </div>

        <script src="js/app.js"></script>


    </body>
</html>


