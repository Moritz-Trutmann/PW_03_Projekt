<!doctype html>
<?php
        $id = $_GET['demo'];
        $jahr = $_GET['Jahr'];
        $file = fopen("div-energie-8.csv", "r");
        if (isset($_GET['demo']) && isset($_GET['Jahr'])) {
            while (!feof($file)) {
                $content = fgetcsv($file);
                $count = count($content);
                for ($i = 0; $i < $count; $i++) {
                    $text = explode(";", $content[$i]);
                    if ($text[1] == $id && $text[0] == $jahr) {
                        echo "Gemeindename: " . $text[2] . "<br>";
                        echo "Einwohner: " . $text[3] . "Person<br>";
                        echo "Energiebezugsflaeche: " . $text[4] . "m2<br>";
                        echo 'Erdölbrennstoffe: ' . $text[5] . 'kg<br> Erdgas: ' . $text[6] . 'kg<br> Andere: ' . $text[7] . 'kg<br> Total: ' . $text[8] . 'kg<br>';
                        $einwohner = intval($text[3]);
                        $bezugsfläche = intval($text[4]);
                        $erdöl = intval($text[5]);
                        $erdgas = intval($text[6]);
                        $andere = intval($text[7]);
                        $total = intval($text[8]);
                    }
                }
            }
        }
        ?>